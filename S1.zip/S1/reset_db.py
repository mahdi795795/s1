import os
from app import db, app

db_path = os.path.join(os.path.dirname(__file__), 'site.db')

# حذف فایل دیتابیس اگر وجود دارد
if os.path.exists(db_path):
    os.remove(db_path)
    print("✅ فایل site.db حذف شد.")
else:
    print("⚠️ فایل site.db وجود نداشت.")

# ساخت مجدد دیتابیس و جدول‌ها
with app.app_context():
    db.create_all()
    print("✅ دیتابیس جدید ساخته شد و جدول‌ها ایجاد شدند.")