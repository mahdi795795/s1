import requests

class Payment:
    def __init__(self, merchant_id, sandbox=False):
        self.merchant_id = merchant_id
        self.sandbox = sandbox
        self.api_url = (
            "https://sandbox.zarinpal.com/pg/rest/WebGate/"
            if sandbox else
            "https://www.zarinpal.com/pg/rest/WebGate/"
        )
        self.startpay_url = (
            "https://sandbox.zarinpal.com/pg/StartPay/"
            if sandbox else
            "https://www.zarinpal.com/pg/StartPay/"
        )
        self.authority = None

    def request(self, amount, description, callback_url, email="", mobile=""):
        data = {
            "MerchantID": self.merchant_id,
            "Amount": amount,
            "Description": description,
            "CallbackURL": callback_url,
            "Email": email,
            "Mobile": mobile
        }
        try:
            response = requests.post(self.api_url + "PaymentRequest.json", json=data)
            if response.status_code != 200:
                print("❌ خطا در اتصال به زرین‌پال:", response.status_code)
                return SimpleResponse(False, None)
            res = response.json()
            if res.get("Status") == 100:
                self.authority = res["Authority"]
                return SimpleResponse(True, self.authority)
            print("⚠️ پاسخ ناموفق از زرین‌پال:", res)
            return SimpleResponse(False, None)
        except Exception as e:
            print("❌ خطا در ارسال درخواست پرداخت:", e)
            return SimpleResponse(False, None)

    def verify(self, authority, amount):
        data = {
            "MerchantID": self.merchant_id,
            "Amount": amount,
            "Authority": authority
        }
        try:
            response = requests.post(self.api_url + "PaymentVerification.json", json=data)
            if response.status_code != 200:
                print("❌ خطا در اتصال به زرین‌پال:", response.status_code)
                return SimpleResponse(False, None)
            res = response.json()
            if res.get("Status") == 100:
                return SimpleResponse(True, res.get("RefID"))
            print("⚠️ پرداخت تأیید نشد:", res)
            return SimpleResponse(False, None)
        except Exception as e:
            print("❌ خطا در تأیید پرداخت:", e)
            return SimpleResponse(False, None)

    def authority_url(self):
        return self.startpay_url + self.authority

class SimpleResponse:
    def __init__(self, ok, authority_or_refid):
        self.ok = ok
        self.authority = authority_or_refid
        self.status = 100 if ok else -1